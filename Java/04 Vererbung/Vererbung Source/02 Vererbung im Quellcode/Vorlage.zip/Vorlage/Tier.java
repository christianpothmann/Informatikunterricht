public class Tier
{
    String art, name;
    
    public void setArt(String pa)
    {
        art = pa;
    }

    public String getArt()
    {
        return art;
    }

    public void setName(String pn)
    {
        name = pn;
    }

    public String getName()
    {
        return name;
    }
}